PK TaskFlow website
===================

Files:
- index.html: complete responsive website. No build step required.

Publish using GitHub + Vercel:
1. Create a GitHub repository named pk-taskflow.
2. Add/upload index.html to the repository root and commit it.
3. Sign in to Vercel and import the GitHub repository.
4. For a plain HTML site, select Framework Preset: Other if asked; no build command is needed.
5. Deploy. Vercel will provide a vercel.app address.
6. Buy a domain from a domain registrar if you want your own domain. In Vercel Project Settings > Domains, add it and follow the exact DNS instructions Vercel displays.

Storage:
- Tasks and theme are saved in localStorage in the same browser on the same device.
- Clearing site data/browser storage can erase tasks.
- Tasks do not sync between devices.
- No account or server is required.

Brand:
- PK monogram represents Pabitra Kundu.
